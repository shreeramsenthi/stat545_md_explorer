#' powers.
#'
#' @name powers
#' @docType package
#' @details Some details will go here
NULL
